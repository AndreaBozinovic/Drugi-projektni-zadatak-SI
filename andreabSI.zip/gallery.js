const images = document.querySelectorAll(".image-carousel img");
let currentIndex = 0;

function showImage(index) {
  images.forEach((img, i) => {
    img.style.transform = `rotateY(${(i - index) * 90}deg)`;
    img.style.opacity = i === index ? "1" : "0";
  });
}

function nextImage() {
  currentIndex = (currentIndex + 1) % images.length;
  showImage(currentIndex);
}

function prevImage() {
  currentIndex = (currentIndex - 1 + images.length) % images.length;
  showImage(currentIndex);
}

showImage(currentIndex);

document.getElementById("nextBtn").addEventListener("click", nextImage);
document.getElementById("prevBtn").addEventListener("click", prevImage);
