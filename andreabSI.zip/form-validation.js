document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const message = document.getElementById("message").value.trim();

  const nameError = document.getElementById("nameError");
  const emailError = document.getElementById("emailError");
  const phoneError = document.getElementById("phoneError");
  const messageError = document.getElementById("messageError");

  nameError.textContent = "";
  emailError.textContent = "";
  phoneError.textContent = "";
  messageError.textContent = "";

  let isValid = true;

  if (name === "") {
    nameError.textContent = "Ime je obavezno.";
    isValid = false;
  }

  if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
    emailError.textContent = "Unesite važeću email adresu.";
    isValid = false;
  }

  if (!/^\d{9,15}$/.test(phone)) {
    phoneError.textContent = "Unesite važeći broj telefona (9-15 cifara).";
    isValid = false;
  }

  if (message === "") {
    messageError.textContent = "Poruka ne može biti prazna.";
    isValid = false;
  }

  if (isValid) {
    alert("Vaša poruka je uspješno poslana! Hvala što ste nas kontaktirali.");
    document.getElementById("contactForm").reset();
  }
});
